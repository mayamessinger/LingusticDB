# Milestone 1

## Populating sample database
create.sql and load.sql files contain the tables and views of the sample database, and sample data to populate with
* dropdb ling; createdb ling; psql ling -af create.sql
* psql ling -af load.sql